
public interface Lab {

}
