/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author julio
 */
public class Infoesc {
    
    	public String descripcion(){
		String mensaje = "";
		mensaje = "\nPequegames es un programa con juego infantiles \ndesarrollado para que el tiempo de sus ninios \npasen frente a la pantalla sea lo mas divertido \ny beneficioso para ellos. Enfoncadose en el desarrollo \nde sus actividades cognitivas";
		return mensaje;
	}
    
}
